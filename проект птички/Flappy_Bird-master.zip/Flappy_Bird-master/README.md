# Flappy_Bird
MyGame
You need click on "Plus" to fly up and pass through tubes.
